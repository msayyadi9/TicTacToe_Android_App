package com.example.tictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Create the game with default constructor
    private TicTacToe appTicTacToe = new TicTacToe();

    // Define TextView
    private TextView textDisplay;

    // Define private ImageViews
    private ImageView iView00;
    private ImageView iView01;
    private ImageView iView02;
    private ImageView iView10;
    private ImageView iView11;
    private ImageView iView12;
    private ImageView iView20;
    private ImageView iView21;
    private ImageView iView22;

    private ImageView winnerLine;

    private ImageView hideBack;

    // Define private Buttons
    private Button bttn00;
    private Button bttn01;
    private Button bttn02;
    private Button bttn10;
    private Button bttn11;
    private Button bttn12;
    private Button bttn20;
    private Button bttn21;
    private Button bttn22;

    String np1;
    String np2;

    // Created a new shared preference state to access stored preference variables
    private SharedPreferences prefs;

    // Define new game Button
    private Button newGame;

    // Initializes boolean variables
    boolean hideBackground;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Stores the current variables on the board
        outState.putInt("coordinate_00", appTicTacToe.getCoordinate(0,0));
        outState.putInt("coordinate_01", appTicTacToe.getCoordinate(0,1));
        outState.putInt("coordinate_02", appTicTacToe.getCoordinate(0,2));

        outState.putInt("coordinate_10", appTicTacToe.getCoordinate(1,0));
        outState.putInt("coordinate_11", appTicTacToe.getCoordinate(1,1));
        outState.putInt("coordinate_12", appTicTacToe.getCoordinate(1,2));

        outState.putInt("coordinate_20", appTicTacToe.getCoordinate(2,0));
        outState.putInt("coordinate_21", appTicTacToe.getCoordinate(2,1));
        outState.putInt("coordinate_22", appTicTacToe.getCoordinate(2,2));

        outState.putInt("whose_turn", appTicTacToe.getTurnTracker());

        outState.putString("player1_Name", appTicTacToe.getPlayerOneName());
        outState.putString("player2_Name", appTicTacToe.getPlayerTwoName());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Map the ImageViews and Buttons to their id

        // Image Views:
        // Row 1 //
        iView00 = (ImageView) findViewById(R.id.tile00);
        iView01 = (ImageView) findViewById(R.id.tile01);
        iView02 = (ImageView) findViewById(R.id.tile02);
        // Row 2 //
        iView10 = (ImageView) findViewById(R.id.tile10);
        iView11 = (ImageView) findViewById(R.id.tile11);
        iView12 = (ImageView) findViewById(R.id.tile12);
        // Row 3 //
        iView20 = (ImageView) findViewById(R.id.tile20);
        iView21 = (ImageView) findViewById(R.id.tile21);
        iView22 = (ImageView) findViewById(R.id.tile22);

        hideBack = (ImageView) findViewById(R.id.whiteBack);

        // Buttons:
        // Row 1 //
        bttn00 = (Button) findViewById(R.id.button00);
        bttn01 = (Button) findViewById(R.id.button01);
        bttn02 = (Button) findViewById(R.id.button02);
        // Row 2 //
        bttn10 = (Button) findViewById(R.id.button10);
        bttn11 = (Button) findViewById(R.id.button11);
        bttn12 = (Button) findViewById(R.id.button12);
        // Row 3 //
        bttn20 = (Button) findViewById(R.id.button20);
        bttn21 = (Button) findViewById(R.id.button21);
        bttn22 = (Button) findViewById(R.id.button22);

        // Gets the names from the title activity
        Intent intent = getIntent();
        np1 = intent.getExtras().getString("player_1");
        np2 = intent.getExtras().getString("player_2");

        appTicTacToe.setPlayerOneName(np1);
        appTicTacToe.setPlayerTwoName(np2);

        // New Game Button
        newGame = (Button) findViewById(R.id.newGameButton);


        // TextView:
        textDisplay = (TextView) findViewById(R.id.textDisp);
        String initialTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
        textDisplay.setText(initialTurn);


        // Line that shows how the player won
        winnerLine = (ImageView) findViewById(R.id.lineCross);

        // Set all of my preference booleans to display these upon being true
        if(hideBackground){
            hideBack.setImageResource(R.drawable.white);
        }

        newGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Resets the board
                appTicTacToe.newGame();

                // Deletes the 'X' and 'O' moves
                iView00.setImageResource(R.drawable.blank_move);
                iView01.setImageResource(R.drawable.blank_move);
                iView02.setImageResource(R.drawable.blank_move);
                iView10.setImageResource(R.drawable.blank_move);
                iView11.setImageResource(R.drawable.blank_move);
                iView12.setImageResource(R.drawable.blank_move);
                iView20.setImageResource(R.drawable.blank_move);
                iView21.setImageResource(R.drawable.blank_move);
                iView22.setImageResource(R.drawable.blank_move);

                // Removes the winner line
                winnerLine.setImageResource(R.drawable.case_default);

                // Loser goes first on new game
                appTicTacToe.changeTurn();
                String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                textDisplay.setText(nextTurn);
            }
        });

        // Buttons for Row 1 //
        bttn00.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(0,0) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(0, 0, 1);

                        // Draws the 'X'
                        iView00.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(0, 0, 2);

                        // Draws the 'X'
                        iView00.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        bttn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(0,1) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(0, 1, 1);

                        // Draws the 'X'
                        iView01.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(0, 1, 2);

                        // Draws the 'X'
                        iView01.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        bttn02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(0,2) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(0, 2, 1);

                        // Draws the 'X'
                        iView02.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(0, 2, 2);

                        // Draws the 'X'
                        iView02.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });


        // Buttons for Row 2 //
        bttn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(1,0) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(1, 0, 1);

                        // Draws the 'X'
                        iView10.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(1, 0, 2);

                        // Draws the 'X'
                        iView10.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        bttn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(1,1) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(1, 1, 1);

                        // Draws the 'X'
                        iView11.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(1, 1, 2);

                        // Draws the 'X'
                        iView11.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        bttn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(1,2) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(1, 2, 1);

                        // Draws the 'X'
                        iView12.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(1, 2, 2);

                        // Draws the 'X'
                        iView12.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });


        // Buttons for Row 3 //
        bttn20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(2,0) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(2, 0, 1);

                        // Draws the 'X'
                        iView20.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(2, 0, 2);

                        // Draws the 'X'
                        iView20.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        bttn21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(2,1) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(2, 1, 1);

                        // Draws the 'X'
                        iView21.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(2, 1, 2);

                        // Draws the 'X'
                        iView21.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        bttn22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check to see if the tile already has a move in it
                if(appTicTacToe.getCoordinate(2,2) != 0){
                    Toast invalid = Toast.makeText(getApplicationContext(),"Invalid Move",Toast.LENGTH_LONG);
                    invalid.setGravity(Gravity.CENTER, 0, 0);
                    invalid.show();
                }
                // If the tile doesn't have a move in it, continue
                else {
                    // If it's player 1's turn
                    if ((appTicTacToe.getTurnTracker()) % 2 == 0) {

                        // Sets tile to player 1's move
                        appTicTacToe.setCoordinate(2, 2, 1);

                        // Draws the 'X'
                        iView22.setImageResource(R.drawable.x_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                    // If it's player 2's turn
                    else {

                        // Sets tile to player 2's move
                        appTicTacToe.setCoordinate(2, 2, 2);

                        // Draws the 'X'
                        iView22.setImageResource(R.drawable.o_move);

                        // Checks to see if there was a winner or a tie
                        int win = appTicTacToe.checkForWinner();
                        if(win != 0){
                            // Print the winning message
                            textDisplay.setText(appTicTacToe.printWinnerName(win));

                            // Draws the line to show how the player won
                            int checkLine = appTicTacToe.winCase();
                            switch(checkLine){
                                case 1:
                                    winnerLine.setImageResource(R.drawable.case1);
                                    break;
                                case 2:
                                    winnerLine.setImageResource(R.drawable.case2);
                                    break;
                                case 3:
                                    winnerLine.setImageResource(R.drawable.case3);
                                    break;
                                case 4:
                                    winnerLine.setImageResource(R.drawable.case4);
                                    break;
                                case 5:
                                    winnerLine.setImageResource(R.drawable.case5);
                                    break;
                                case 6:
                                    winnerLine.setImageResource(R.drawable.case6);
                                    break;
                                case 7:
                                    winnerLine.setImageResource(R.drawable.case7);
                                    break;
                                case 8:
                                    winnerLine.setImageResource(R.drawable.case8);
                                    break;
                                case 9:
                                    winnerLine.setImageResource(R.drawable.case_default);
                                    break;
                                default:
                                    winnerLine.setImageResource(R.drawable.case_default);
                            }
                        }
                        // If there isn't a winner or a tie, change turn
                        else {
                            appTicTacToe.changeTurn();
                            String nextTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                            textDisplay.setText(nextTurn);
                        }
                    }
                }
            }
        });

        // Uses a preference manager to access the preferences.xml file
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        // Re-assigns the TextViews and variables with the saved instances if there is saved data
        if(savedInstanceState != null) {

            // Sets the grid back to the way it was
            appTicTacToe.setCoordinate(0, 0, savedInstanceState.getInt("coordinate_00"));
            appTicTacToe.setCoordinate(0, 1, savedInstanceState.getInt("coordinate_01"));
            appTicTacToe.setCoordinate(0, 2, savedInstanceState.getInt("coordinate_02"));
            appTicTacToe.setCoordinate(1, 0, savedInstanceState.getInt("coordinate_10"));
            appTicTacToe.setCoordinate(1, 1, savedInstanceState.getInt("coordinate_11"));
            appTicTacToe.setCoordinate(1, 2, savedInstanceState.getInt("coordinate_12"));
            appTicTacToe.setCoordinate(2, 0, savedInstanceState.getInt("coordinate_20"));
            appTicTacToe.setCoordinate(2, 1, savedInstanceState.getInt("coordinate_21"));
            appTicTacToe.setCoordinate(2, 2, savedInstanceState.getInt("coordinate_22"));

            appTicTacToe.setTurnTracker(savedInstanceState.getInt("whose_turn"));

            appTicTacToe.setPlayerOneName(savedInstanceState.getString("player1_Name"));
            appTicTacToe.setPlayerTwoName(savedInstanceState.getString("player2_Name"));

            // Checks again to see if there was a winner
            if(appTicTacToe.checkForWinner() != 0){
                int win = appTicTacToe.checkForWinner();
                textDisplay.setText(appTicTacToe.printWinnerName(win));
                int checkLine = appTicTacToe.winCase();
                switch(checkLine){
                    case 1:
                        winnerLine.setImageResource(R.drawable.case1);
                        break;
                    case 2:
                        winnerLine.setImageResource(R.drawable.case2);
                        break;
                    case 3:
                        winnerLine.setImageResource(R.drawable.case3);
                        break;
                    case 4:
                        winnerLine.setImageResource(R.drawable.case4);
                        break;
                    case 5:
                        winnerLine.setImageResource(R.drawable.case5);
                        break;
                    case 6:
                        winnerLine.setImageResource(R.drawable.case6);
                        break;
                    case 7:
                        winnerLine.setImageResource(R.drawable.case7);
                        break;
                    case 8:
                        winnerLine.setImageResource(R.drawable.case8);
                        break;
                    case 9:
                        winnerLine.setImageResource(R.drawable.case_default);
                        break;
                    default:
                        winnerLine.setImageResource(R.drawable.case_default);
                }
            }
            else {
                initialTurn = String.format("%s's turn", appTicTacToe.whoseTurn());
                textDisplay.setText(initialTurn);
            }

            if (appTicTacToe.getCoordinate(0, 0) == 1) {
                iView00.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(0, 1) == 1) {
                iView01.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(0, 2) == 1) {
                iView02.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(1, 0) == 1) {
                iView10.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(1, 1) == 1) {
                iView11.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(1, 2) == 1) {
                iView12.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(2, 0) == 1) {
                iView20.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(2, 1) == 1) {
                iView21.setImageResource(R.drawable.x_move);
            } if (appTicTacToe.getCoordinate(2, 2) == 1) {
                iView22.setImageResource(R.drawable.x_move);
            }

            if (appTicTacToe.getCoordinate(0, 0) == 2) {
                iView00.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(0, 1) == 2) {
                iView01.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(0, 2) == 2) {
                iView02.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(1, 0) == 2) {
                iView10.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(1, 1) == 2) {
                iView11.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(1, 2) == 2) {
                iView12.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(2, 0) == 2) {
                iView20.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(2, 1) == 2) {
                iView21.setImageResource(R.drawable.o_move);
            } if (appTicTacToe.getCoordinate(2, 2) == 2) {
                iView22.setImageResource(R.drawable.o_move);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Accesses the boolean data by looking up the preference Keys
        hideBackground = prefs.getBoolean("no_background", false);

        if(hideBackground){
            hideBack.setImageResource(R.drawable.white);
        }
        else{
            hideBack.setImageResource(R.drawable.blank_move);
        }
    }

    // Creates the option menu clickable that can create the menu buttons
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.tictactoe_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            // Assigns what will happen when you click on menu settings
            case R.id.menu_settings:
                // Goes to the preference menu
                startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
                return true;
            case R.id.menu_about:
                // Creates a toast message
                Toast toast = Toast.makeText(this,"Get 3 in a row!", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

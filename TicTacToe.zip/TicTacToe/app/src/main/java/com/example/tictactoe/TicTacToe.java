package com.example.tictactoe;

public class TicTacToe {

    private int[][] gameBoard = {{0,0,0},{0,0,0},{0,0,0}};

    private String playerOneName;
    private String playerTwoName;

    private int turnTracker;

    // Tic Tac Toe constructor //
    public TicTacToe(){

        this.playerOneName = "Player 1";
        this.playerTwoName = "Player 2";

        this.turnTracker = 0;
    }

    public int getCoordinate(int row, int col){
        return this.gameBoard[row][col];
    }
    public void setCoordinate(int row, int col, int playerMove){
        this.gameBoard[row][col] = playerMove;
    }

    public int getTurnTracker(){
        return this.turnTracker;
    }
    public void setTurnTracker(int turnNumber){
        this.turnTracker = turnNumber;
    }

    public String getPlayerOneName(){
        return this.playerOneName;
    }
    public void setPlayerOneName(String playerName){
        this.playerOneName = playerName;
    }

    public String getPlayerTwoName(){
        return this.playerTwoName;
    }
    public void setPlayerTwoName(String playerName){
        this.playerTwoName = playerName;
    }


    public void changeTurn(){
        this.turnTracker += 1;
    }

    public String whoseTurn(){
        if(turnTracker % 2 == 0){
            return this.playerOneName;
        }
        else{
            return this.playerTwoName;
        }
    }

    public int checkForWinner(){

        // Player 1 winning cases

        // Player 1 : Case 1
        if(getCoordinate(0,0) == 1 &&
                getCoordinate(1,0) == 1 &&
                getCoordinate(2,0) == 1){
           return 1;
        }
        // Player 1 : Case 2
        else if(getCoordinate(0,1) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(2,1) == 1){
            return 1;
        }
        // Player 1 : Case 3
        else if(getCoordinate(0,2) == 1 &&
                getCoordinate(1,2) == 1 &&
                getCoordinate(2,2) == 1){
            return 1;
        }
        // Player 1 : Case 4
        else if(getCoordinate(2,0) == 1 &&
                getCoordinate(2,1) == 1 &&
                getCoordinate(2,2) == 1){
            return 1;
        }
        // Player 1 : Case 5
        else if(getCoordinate(1,0) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(1,2) == 1){
            return 1;
        }
        // Player 1 : Case 6
        else if(getCoordinate(0,0) == 1 &&
                getCoordinate(0,1) == 1 &&
                getCoordinate(0,2) == 1){
            return 1;
        }
        // Player 1 : Case 7
        else if(getCoordinate(2,0) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(0,2) == 1){
            return 1;
        }
        // Player 1 : Case 8
        else if(getCoordinate(0,0) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(2,2) == 1){
            return 1;
        }

        // Player 2 winning cases

        // Player 2 : Case 1
        else if(getCoordinate(0,0) == 2 &&
                getCoordinate(1,0) == 2 &&
                getCoordinate(2,0) == 2){
            return 2;
        }
        // Player 2 : Case 2
        else if(getCoordinate(0,1) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(2,1) == 2){
            return 2;
        }
        // Player 2 : Case 3
        else if(getCoordinate(0,2) == 2 &&
                getCoordinate(1,2) == 2 &&
                getCoordinate(2,2) == 2){
            return 2;
        }
        // Player 2 : Case 4
        else if(getCoordinate(2,0) == 2 &&
                getCoordinate(2,1) == 2 &&
                getCoordinate(2,2) == 2){
            return 2;
        }
        // Player 2 : Case 5
        else if(getCoordinate(1,0) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(1,2) == 2){
            return 2;
        }
        // Player 2 : Case 6
        else if(getCoordinate(0,0) == 2 &&
                getCoordinate(0,1) == 2 &&
                getCoordinate(0,2) == 2){
            return 2;
        }
        // Player 2 : Case 7
        else if(getCoordinate(2,0) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(0,2) == 2){
            return 2;
        }
        // Player 2 : Case 8
        else if(getCoordinate(0,0) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(2,2) == 2){
            return 2;
        }

        // Tie game case

        // Tie : Case 1
        else if(getCoordinate(0,0) != 0 &&
                getCoordinate(0,1) != 0 &&
                getCoordinate(0,2) != 0 &&
                getCoordinate(1,0) != 0 &&
                getCoordinate(1,1) != 0 &&
                getCoordinate(1,2) != 0 &&
                getCoordinate(2,0) != 0 &&
                getCoordinate(2,1) != 0 &&
                getCoordinate(2,2) != 0){
            return 3;
        }
        else {
            return 0;
        }
    }

    public int winCase(){
        // Player 1 winning cases

        // Case 1
        if(getCoordinate(0,0) == 1 &&
                getCoordinate(1,0) == 1 &&
                getCoordinate(2,0) == 1){
            return 1;
        }
        // Case 2
        else if(getCoordinate(0,1) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(2,1) == 1){
            return 2;
        }
        // Case 3
        else if(getCoordinate(0,2) == 1 &&
                getCoordinate(1,2) == 1 &&
                getCoordinate(2,2) == 1){
            return 3;
        }
        // Case 4
        else if(getCoordinate(2,0) == 1 &&
                getCoordinate(2,1) == 1 &&
                getCoordinate(2,2) == 1){
            return 4;
        }
        // Case 5
        else if(getCoordinate(1,0) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(1,2) == 1){
            return 5;
        }
        // Case 6
        else if(getCoordinate(0,0) == 1 &&
                getCoordinate(0,1) == 1 &&
                getCoordinate(0,2) == 1){
            return 6;
        }
        // Case 7
        else if(getCoordinate(2,0) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(0,2) == 1){
            return 7;
        }
        // Case 8
        else if(getCoordinate(0,0) == 1 &&
                getCoordinate(1,1) == 1 &&
                getCoordinate(2,2) == 1){
            return 8;
        }

        // Player 2 winning cases

        // Case 1
        if(getCoordinate(0,0) == 2 &&
                getCoordinate(1,0) == 2 &&
                getCoordinate(2,0) == 2){
            return 1;
        }
        // Case 2
        else if(getCoordinate(0,1) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(2,1) == 2){
            return 2;
        }
        // Case 3
        else if(getCoordinate(0,2) == 2 &&
                getCoordinate(1,2) == 2 &&
                getCoordinate(2,2) == 2){
            return 3;
        }
        // Case 4
        else if(getCoordinate(2,0) == 2 &&
                getCoordinate(2,1) == 2 &&
                getCoordinate(2,2) == 2){
            return 4;
        }
        // Case 5
        else if(getCoordinate(1,0) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(1,2) == 2){
            return 5;
        }
        // Case 6
        else if(getCoordinate(0,0) == 2 &&
                getCoordinate(0,1) == 2 &&
                getCoordinate(0,2) == 2){
            return 6;
        }
        // Case 7
        else if(getCoordinate(2,0) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(0,2) == 2){
            return 7;
        }
        // Case 8
        else if(getCoordinate(0,0) == 2 &&
                getCoordinate(1,1) == 2 &&
                getCoordinate(2,2) == 2){
            return 8;
        }

        // Case 9 (Tie Game)
        else if(getCoordinate(0,0) != 0 &&
                getCoordinate(0,1) != 0 &&
                getCoordinate(0,2) != 0 &&
                getCoordinate(1,0) != 0 &&
                getCoordinate(1,1) != 0 &&
                getCoordinate(1,2) != 0 &&
                getCoordinate(2,0) != 0 &&
                getCoordinate(2,1) != 0 &&
                getCoordinate(2,2) != 0){
            return 9;
        }
        else {
            return 0;
        }

    }

    public String printWinnerName(int outcome){
        if(outcome == 1){
            String winner = String.format("%s Wins!", this.playerOneName);
            return winner;
        }

        else if(outcome == 2){
            String winner = String.format("%s Wins!", this.playerTwoName);
            return winner;
        }

        else if(outcome == 3){
            return "Tie Game!";
        }
        else{
            return "";
        }
    }

    public void newGame(){
        this.gameBoard[0][0] = 0;
        this.gameBoard[0][1] = 0;
        this.gameBoard[0][2] = 0;
        this.gameBoard[1][0] = 0;
        this.gameBoard[1][1] = 0;
        this.gameBoard[1][2] = 0;
        this.gameBoard[2][0] = 0;
        this.gameBoard[2][1] = 0;
        this.gameBoard[2][2] = 0;
    }
}

package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class StartScreenActivity extends AppCompatActivity {

    private Button startGame;
    private EditText namePlayer1;
    private EditText namePlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_screen);

        startGame = (Button) findViewById(R.id.startButton);

        namePlayer1 = (EditText) findViewById(R.id.p1_name);
        namePlayer2 = (EditText) findViewById(R.id.p2_name);

        startGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String np1 = namePlayer1.getText().toString();
                String np2 = namePlayer2.getText().toString();
                openMainActivity(np1,np2);
            }
        });
    }

    public void openMainActivity(String np1, String np2){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("player_1", np1);
        intent.putExtra("player_2", np2);
        startActivity(intent);
    }

}
